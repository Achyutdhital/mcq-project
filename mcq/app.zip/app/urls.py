from django.urls import path
from . import views
from . views import (CategoriesView,QuestionsView)

urlpatterns = [
    path('',views.index),
    path('category', CategoriesView.as_view(), name='categories'),
    path('category/<slug:slug>', CategoriesView.as_view(), name='categories'),
    # path('questions_sets',QuestionsView.as_view(), name='questionsset'),
    # path('questions_sets/<slug:slug>',QuestionsView.as_view(), name='questions')

]