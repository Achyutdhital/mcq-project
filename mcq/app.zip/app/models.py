from django.db import models
from autoslug import AutoSlugField
from account.models import User

class Categories(models.Model):
    categories_name = models.CharField(max_length=500)
    image = models.ImageField(upload_to='categoriesimage/')
    order_number = models.IntegerField()
    previous_price = models.IntegerField(null=True, blank=True)
    current_price = models.IntegerField()
    short_descriptions = models.TextField()
    categories_slug = AutoSlugField(populate_from='categories_name', unique=True, default=None)

    class Meta:
        ordering = ['-order_number']

    def __str__(self):
        return self.categories_name


payment_status =(
    ('paid','Paid'),
    ('pending','Pending')
)


class QuestionSets(models.Model):
    categorie = models.ForeignKey(Categories, on_delete=models.CASCADE, related_name='question_sets')
    set_name = models.CharField(max_length=300)
    order_number = models.IntegerField()
    is_free = models.BooleanField()
    questions_set_slug = AutoSlugField(populate_from='set_name', unique=True, default=None)

    
    class Meta:
        ordering = ['order_number']

    def __str__(self):
        return self.set_name

class Questions(models.Model):
    set_name = models.ForeignKey(QuestionSets, on_delete=models.CASCADE, related_name='question_set_name')
    question = models.CharField(max_length=300)
    question_slug = AutoSlugField(populate_from='question', unique=True, default=None)

    class Meta:
        ordering = ['-id']

    def __str__(self):
        return self.question

class Answer(models.Model):
    question = models.ForeignKey(Questions, on_delete=models.CASCADE, related_name='answers')
    answer = models.CharField(max_length=255)
    is_correct = models.BooleanField(default=False)

    def __str__(self):
        return self.answer



class Purchases(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='users')
    sets = models.ForeignKey(QuestionSets, on_delete=models.CASCADE, related_name='questionset')
    payment_status = models.CharField(choices=payment_status, max_length=200, default='pending')
    

    class Meta:
        ordering=['-id']

    def __str__(self):
        return f"{self.user.name} - {self.sets.set_name} ({self.payment_status})"

