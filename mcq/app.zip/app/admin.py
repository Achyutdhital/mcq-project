from django.contrib import admin
from . models import Categories, QuestionSets,Questions, Answer,Purchases


class PurchasesAdmin(admin.ModelAdmin):
    model =Purchases
    list_display =['user','sets','payment_status']
admin.site.register(Purchases,PurchasesAdmin)

class CategoriesAdmin(admin.ModelAdmin):
    model = Categories
    list_display =['categories_name','previous_price','current_price','short_descriptions','image','order_number']
admin.site.register(Categories, CategoriesAdmin)


class QuestionSetsAdmin(admin.ModelAdmin):
    model = QuestionSets
    list_display =['set_name','categorie','is_free','order_number']
admin.site.register(QuestionSets, QuestionSetsAdmin)


class AnswerAdmin(admin.TabularInline):
    model = Answer
    max_num =4

class QuestionAdmin(admin.ModelAdmin):
    inlines =[AnswerAdmin]
admin.site.register(Questions, QuestionAdmin)