from django.shortcuts import render, HttpResponse
from . models import Categories, Questions, QuestionSets, Answer, Purchases
from rest_framework.views import APIView
from rest_framework import filters
from rest_framework import viewsets
from rest_framework import generics
from rest_framework import status
from rest_framework.response import Response
from .serializers import CategoriesSerailizers,QuestionSetSerializers,QuestionSerializer

class CategoriesView(generics.ListAPIView):
    queryset = Categories.objects.all().order_by('order_number')
    serializer_class = CategoriesSerailizers

    def list(self, request, *args, **kwargs):
        if 'slug' in kwargs:
            category = Categories.objects.get(categories_slug=kwargs['slug'])
            print(category)
            question_sets_queryset = QuestionSets.objects.filter(categorie=category)
            print(question_sets_queryset)
            category_serializer = CategoriesSerailizers(category)
            question_sets_serializer = QuestionSetSerializers(question_sets_queryset, many=True)
            
            response_data = {
                "category": category_serializer.data,
                "question_sets": question_sets_serializer.data,
                "success": True
            }
        else:
            queryset = self.get_queryset()
            serializer = CategoriesSerailizers(queryset, many=True)
            response_data = {
                "data": serializer.data,
                "success": True
            }

        return Response(response_data, status=status.HTTP_200_OK)
    




class QuestionsView(generics.ListAPIView):
    serializer_class = QuestionSerializer

    def get_queryset(self):
        if 'slug' in self.kwargs:
            print(self.kwargs['slug'])
            question_set = QuestionSets.objects.get(questions_set_slug=self.kwargs['slug'])
            print(question_set)
            return Questions.objects.filter(set_name=question_set)
        else:
            return QuestionSets.objects.all()

    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        print(queryset)
        serializer = self.get_serializer(queryset, many=True)

        response_data = {
            "data": serializer.data,
            "success": True
        }

        return Response(response_data, status=status.HTTP_200_OK)
    
def index(request):
    return HttpResponse("Hello")