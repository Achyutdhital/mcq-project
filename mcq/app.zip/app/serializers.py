from . models import Categories, Questions, QuestionSets, Answer, Purchases
from rest_framework import serializers


domain = "http://192.168.18.11:8000"

class CategoriesSerailizers(serializers.ModelSerializer):
    image = serializers.SerializerMethodField('get_image_url')

    class Meta:
        model = Categories
        fields =['categories_name','image','order_number','previous_price','current_price','short_descriptions','categories_slug']

    def get_image_url(self, obj):
        return f'{domain}{obj.image.url}'
    

class QuestionSetSerializers(serializers.ModelSerializer):
    categorie = CategoriesSerailizers(many=True, read_only=True, source='question_sets')

    class Meta:
        model = QuestionSets
        fields = ['categorie', 'set_name', 'order_number', 'is_free', 'questions_set_slug']


class AnswerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Answer
        fields =['question','answer','is_correct']

class QuestionSerializer(serializers.ModelSerializer):
    set_name =  serializers.SlugRelatedField(
        queryset=QuestionSets.objects.all(), slug_field="set_name"
    )
    answer =QuestionSetSerializers(many = True, read_only = True)
    class Meta:
        model = Questions
        fields = ['set_name', 'question','answer']





